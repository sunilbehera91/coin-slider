import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
// import { SelectedRoutersComponent } from './components/selected-routers/selected-routers.component';
import { RouteCallComponent } from './components/route-call/route-call.component';
import { HomeComponent } from './components/home/home.component';
import { SelectedComponent } from './components/selected/selected.component';
import { SelectedRoutersComponent } from './components/selected-routers/selected-routers.component';
import { RoutersComponent } from './components/selected-routers/routers/routers.component';

import { SelectedExchangeComponent } from './components/selected/selected-exchange/selected-exchange.component';
const routes: Routes = [
  {path: '', redirectTo: '/trafficHawk', pathMatch: 'full'},
  {path: 'trafficHawk', component: HomeComponent},
  {path: 'selected',component: SelectedComponent,
    children: [
              {path: 'exchange',component: SelectedExchangeComponent} 
              ]
  },
  {path: 'SelectedRouters',component: SelectedRoutersComponent,
  children: [
            {path: 'routers',component: RoutersComponent} 
            ]
},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: [
  ],
})
export class AppRoutingModule { }
