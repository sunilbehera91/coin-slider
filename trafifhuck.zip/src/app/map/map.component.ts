import { Component, OnInit, AfterViewInit, ViewChild, Input } from '@angular/core';
import { BingMapsAPILoader, } from "../services/BingMapsAPILoader";
import { LatLongApi } from '../services/LatLongAPI';
import { Subscription } from 'rxjs/internal/Subscription';

declare var Microsoft: any;

@Component({
    selector: 'app-map',
    templateUrl: './map.component.html',
    styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit {
    public map: any;
    public coords: any = [];
    public line: any;
    
    public latlon: any;
    public pathLayer :any;
    public unSubscribeIt: Subscription;
    
    @Input() FromGraph: any;

    constructor(public loader: BingMapsAPILoader ,public latLong: LatLongApi) { }

    ngOnInit() {
        if (this.FromGraph !== undefined) {
            this.primaryMap();
        }

    }

    primaryMap() {
        const options = this.FromGraph;

    
        this.map = new Microsoft.Maps.Map(document.getElementById("primaryMap"), options); 
        this.unSubscribeIt = this.latLong.getPstnListForMapComponent().subscribe(data => {
            if (data !== undefined) {
              this.latlon = data;
              for (var i = 0; i < this.latlon.length; i++) {
                /* A End Details */
                var AEndLat = this.latlon[i]['A End Lat'];
                var AEndLong = this.latlon[i]['A End Long'];
                var langLongForA = new Microsoft.Maps.Location(AEndLat, AEndLong);
                options.center = langLongForA;
                var StatusColor = this.latlon[i].Status;
                let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"><circle cx="5" cy="5" r="100" stroke="orange" stroke-width="4" fill= "${StatusColor}" /></svg>`;
                var pushpinForA = new Microsoft.Maps.Pushpin(langLongForA, {
                  icon: svg,
                  anchor: new Microsoft.Maps.Point(5, 5)
                }); 
               this.map.entities.push(pushpinForA);
                this.coords.push(langLongForA);
      
                /* B End Details */
                var BEndLat = this.latlon[i]['B End Lat'];
                var BEndLong = this.latlon[i]['B End Long'];
                var langLongForB = new Microsoft.Maps.Location(BEndLat, BEndLong);
                options.center = langLongForB;
                 var pushpinForB = new Microsoft.Maps.Pushpin(langLongForB, {
                  icon: svg,
                  anchor: new Microsoft.Maps.Point(5, 5)
                }); 
                this.map.entities.push(pushpinForB);
                this.coords.push(langLongForB);
      
                /* Drawing lines between A End & B End */
                this.line = new Microsoft.Maps.Polyline(this.coords, {
                  strokeColor: StatusColor,
                  strokeThickness: 2,
                  strokeDashArray: [2, 2]
                }); 
                this.map.entities.push(this.line);
                this.coords = [];
              }
             
              this.map.entities = [];
            }
      
          });
        } /* END of Function primaryMap*/
      

      }
      