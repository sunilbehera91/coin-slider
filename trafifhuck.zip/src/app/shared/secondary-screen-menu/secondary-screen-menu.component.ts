import { Component, OnInit } from '@angular/core';
 import { RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-secondary-screen-menu',
  templateUrl: './secondary-screen-menu.component.html',
  styleUrls: ['./secondary-screen-menu.component.scss']
})
export class SecondaryScreenMenuComponent implements OnInit {

  constructor( ) { }

  ngOnInit() {
  }

}
