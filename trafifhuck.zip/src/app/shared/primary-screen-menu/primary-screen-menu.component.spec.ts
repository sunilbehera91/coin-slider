import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimaryScreenHeaderComponent } from './primary-screen-header.component';

describe('PrimaryScreenHeaderComponent', () => {
  let component: PrimaryScreenHeaderComponent;
  let fixture: ComponentFixture<PrimaryScreenHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrimaryScreenHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimaryScreenHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
