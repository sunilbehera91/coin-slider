import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primary-screen-menu',
  templateUrl: './primary-screen-menu.component.html',
  styleUrls: ['./primary-screen-menu.component.scss']
})
export class PrimaryScreenMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
