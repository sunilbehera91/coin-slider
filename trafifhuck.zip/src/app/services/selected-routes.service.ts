import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SelectedRoutesService {
  
  constructor(private http: HttpClient) { }


  loadData() {

    //return this.http.get('./../assets/data/json/data.json');
    return this.http.get('./assets/data/json/data.json');

  }

  getSpecificReport(request: any) {
    let options: any = {
      headers: new HttpHeaders()
                .set('Content-Type', 'application/json')
                .set('userName', '402')
               };

    let url = "http://10.54.8.81:61007/report/getReportAccordingToFilter";

    console.log("Request :: "+JSON.stringify(request))

    return this.http.post(url, request, options);
  }
}
