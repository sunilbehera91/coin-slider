import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { interval, Observable } from 'rxjs';
import { flatMap } from 'rxjs/operators';

@Injectable({
    providedIn: 'root',
})

export class LatLongApi {

    constructor(private http: HttpClient) {

    }

    public getPstnListForMapComponent() {
    
         return this.http.get('../../assets/data/data1.json');
          
    }

    public getPstnListForGraphComponent() {
        return interval(5000)
            .pipe(
                flatMap(() => this.http.get('../../assets/data/data2.json'))
            );
    } 


}