import { TestBed } from '@angular/core/testing';

import { SelectedRoutesService } from './selected-routes.service';

describe('SelectedRoutesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SelectedRoutesService = TestBed.get(SelectedRoutesService);
    expect(service).toBeTruthy();
  });
});
