import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { AngularSplitModule } from 'angular-split';
import {Grid} from "ag-grid/main";
import { AgGridModule } from 'ag-grid-angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import {GraphComponent} from './graph/graph.component';
import {MapComponent} from './map/map.component'
import { AppHeaderComponent } from './shared/app-header/app-header.component';
import { PrimaryScreenMenuComponent } from './shared/primary-screen-menu/primary-screen-menu.component';
import { SecondaryScreenMenuComponent } from './shared/secondary-screen-menu/secondary-screen-menu.component';
// import { RouteCallComponent } from './components/route-call/route-call.component';
import { SelectedComponent } from './components/selected/selected.component';
import { SelectedExchangeComponent } from './components/selected/selected-exchange/selected-exchange.component';
// import { RouteCallSamplingComponent } from './components/route-call/route-call-sampling/route-call-sampling.component';
// import { RouteCallGapComponent } from './components/route-call/route-call-gap/route-call-gap.component';
// import { DestinationCallGappingComponent } from './components/route-call/destination-call-gapping/destination-call-gapping.component';
// import { CallGapNetworkwideComponent } from './components/route-call/call-gap-networkwide/call-gap-networkwide.component';
import { HomeComponent } from './components/home/home.component';
import { SelectedRoutersComponent } from './components/selected-routers/selected-routers.component';

 import {BingMapsAPILoader} from '../app/services/BingMapsAPILoader';
import {LatLongApi} from '../app/services/LatLongAPI'; 

import {
  MapModule,
  MapAPILoader,
  MarkerTypeId,
  IMapOptions,
  IBox,
  IMarkerIconInfo,
  WindowRef,
  DocumentRef,
  MapServiceFactory,
  BingMapAPILoaderConfig,
  BingMapAPILoader,
  GoogleMapAPILoader,
  GoogleMapAPILoaderConfig
} from 'angular-maps';

import { SelectedRoutesService } from '../app/services/selected-routes.service';
import { RouteCallService } from '../app/services/route-call.service';
import { RoutersComponent } from './components/selected-routers/routers/routers.component';

@NgModule({
  declarations: [
    AppComponent,
    GraphComponent,
    MapComponent,
    AppHeaderComponent,
     PrimaryScreenMenuComponent,
     SecondaryScreenMenuComponent,
     HomeComponent,
    // CallGapNetworkwideComponent,
    // DestinationCallGappingComponent,
    // RouteCallGapComponent,
    // RouteCallSamplingComponent,
    // RouteCallComponent,
    SelectedExchangeComponent,
    SelectedComponent,
    SelectedRoutersComponent,
    RoutersComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    AngularSplitModule.forRoot(),
    AgGridModule.withComponents([]),
    BrowserAnimationsModule,
    MatSliderModule,
    MatSlideToggleModule,
    ReactiveFormsModule,
    ],
  providers: [ 
    SelectedRoutesService,
    RouteCallService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
