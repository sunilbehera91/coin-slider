import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secondary-screen',
  templateUrl: './secondary-screen.component.html',
  styleUrls: ['./secondary-screen.component.scss']
})
export class SecondaryScreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
