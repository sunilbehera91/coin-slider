import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedRoutersComponent } from './selected-routers.component';

describe('SelectedRoutersComponent', () => {
  let component: SelectedRoutersComponent;
  let fixture: ComponentFixture<SelectedRoutersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectedRoutersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedRoutersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
