import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-routers',
  templateUrl: './routers.component.html',
  styleUrls: ['./routers.component.scss']
})
export class RoutersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
