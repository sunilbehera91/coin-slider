import { Component, OnInit , AfterViewInit} from '@angular/core';
import { SelectedRoutersService } from './selected-routers.service';
// import "ag-grid-enterprise";
declare var $:any;

@Component({
  selector: 'app-selected-routers',
  templateUrl: './selected-routers.component.html',
  styleUrls: ['./selected-routers.component.scss'],
  providers: [SelectedRoutersService]
})

export class SelectedRoutersComponent implements OnInit, AfterViewInit {
  ngAfterViewInit(): void {
    $('#myModal').modal('show')
    ({
      backdrop: 'static',
      keyboard: false
  })
  }
  constructor() { }
  ngOnInit() {
    
  }

  

}
