import { TestBed } from '@angular/core/testing';

import { SelectedRoutersService } from './selected-routers.service';

describe('SelectedRoutersService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SelectedRoutersService = TestBed.get(SelectedRoutersService);
    expect(service).toBeTruthy();
  });
});
