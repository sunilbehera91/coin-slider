import { TestBed } from '@angular/core/testing';

import { SelectedExchangeService } from './selected-exchange.service';

describe('SelectedExchangeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SelectedExchangeService = TestBed.get(SelectedExchangeService);
    expect(service).toBeTruthy();
  });
});
