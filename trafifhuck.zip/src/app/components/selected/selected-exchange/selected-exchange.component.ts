import { Component, OnInit } from '@angular/core';
import { SelectedRoutesService } from '../../../services/selected-routes.service';


@Component({
  selector: 'app-selected-exchange',
  templateUrl: './selected-exchange.component.html',
  styleUrls: ['./selected-exchange.component.scss'],
  providers: [SelectedRoutesService]
})
export class SelectedExchangeComponent implements OnInit {
  color = 'accent';
  checked = false;
  disabled = false;
  private gridColumnApi;
  private columnDefs;
  private gridOptions;
  private defaultColDef;
  columnTabA: any = [];
  columnTabB: any = [];
  rowData: any = [];

  constructor(public _selectedRoutersService: SelectedRoutesService) { 
    this.columnDefs = [];
    this.defaultColDef = { width: 87 ,
      sortable: true,
      enableBrowserTooltips: true,
    };
  }

  ngOnInit() {

   /* this._selectedRoutersService.loadData().subscribe(res => {
      let headers = res[0];
      const h = [];
      Object.keys(headers).map(item => {
        h.push(
          { headerName: item, field: item, sortable: true, filter: true }
        );
      });

      this.columnTabA = h.slice(0, 4);
      this.columnTabB = h.slice(4, h.length);

      setTimeout(() => {
        this.rowData = res;
      }, 0);

    }, err => {
      console.error(err);
    })*/

    let request = {
      "dashboardId":"NSG_dashboard",
      "userTemplateId": "NSG_VNF_Availabality",
      "jsonString": {
        "filterMap": {
          "NSG_SPECID": "50e4a1fb-0011-43dd-8ecf-694c2e61911b",
          "VNF_NAME": "123456-Fortinet-001-C"
        },
        "intervals": "2019-09-18T00:00:00.000Z/2019-09-31T23:59:59.000Z"
      }
    };
    this._selectedRoutersService.getSpecificReport(request).subscribe((data:any )=> {
      let headers = data.dashboardReports[0].reports[0].response.response[0].events[0];
      const h = [];
      Object.keys(headers).map(item => {
        h.push(
          { headerName: item, field: item, sortable: true, filter: true }
        );
      });

      this.columnTabA = h.slice(0, 4);
      this.columnTabB = h.slice(4, h.length);
      let dataSet=[];
      for (let i = 0; i <  data.dashboardReports[0].reports[0].response.response.length; i++) {
        dataSet.push(data.dashboardReports[0].reports[0].response.response[i].events[0])
      }
      setTimeout(() => {
        this.rowData = dataSet;
      }, 0);

    }, err => {
      console.error(err);
    
  });
    
  }

}
