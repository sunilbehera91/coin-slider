import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedExchangeComponent } from './selected-exchange.component';

describe('SelectedExchangeComponent', () => {
  let component: SelectedExchangeComponent;
  let fixture: ComponentFixture<SelectedExchangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectedExchangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedExchangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
