import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $:any;

@Component({
  selector: 'app-selected',
  templateUrl: './selected.component.html',
  styleUrls: ['./selected.component.scss']
})
export class SelectedComponent implements OnInit,AfterViewInit {
  ngAfterViewInit(): void {
    $('#myModal').modal('show')
    ({
      backdrop: 'static',
      keyboard: false
  })
  }
  constructor() { }
  ngOnInit() {
    
  }

  

}
