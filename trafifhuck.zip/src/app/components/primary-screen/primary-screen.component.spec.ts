import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimaryScreenComponent } from './primary-screen.component';

describe('PrimaryScreenComponent', () => {
  let component: PrimaryScreenComponent;
  let fixture: ComponentFixture<PrimaryScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrimaryScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimaryScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
