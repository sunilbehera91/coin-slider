import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primary-screen',
  templateUrl: './primary-screen.component.html',
  styleUrls: ['./primary-screen.component.scss']
})
export class PrimaryScreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
