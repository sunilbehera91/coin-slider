import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CallGapNetworkwideComponent } from './call-gap-networkwide.component';

describe('CallGapNetworkwideComponent', () => {
  let component: CallGapNetworkwideComponent;
  let fixture: ComponentFixture<CallGapNetworkwideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallGapNetworkwideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallGapNetworkwideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
