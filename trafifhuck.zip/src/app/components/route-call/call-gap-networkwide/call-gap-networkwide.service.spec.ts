import { TestBed } from '@angular/core/testing';

import { CallGapNetworkwideService } from './call-gap-networkwide.service';

describe('CallGapNetworkwideService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CallGapNetworkwideService = TestBed.get(CallGapNetworkwideService);
    expect(service).toBeTruthy();
  });
});
