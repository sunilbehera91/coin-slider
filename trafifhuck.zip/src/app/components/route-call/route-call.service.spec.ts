import { TestBed } from '@angular/core/testing';

import { RouteCallService } from './route-call.service';

describe('RouteCallService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RouteCallService = TestBed.get(RouteCallService);
    expect(service).toBeTruthy();
  });
});
