import { TestBed } from '@angular/core/testing';

import { RouteCallSamplingService } from './route-call-sampling.service';

describe('RouteCallSamplingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RouteCallSamplingService = TestBed.get(RouteCallSamplingService);
    expect(service).toBeTruthy();
  });
});
