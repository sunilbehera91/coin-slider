import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouteCallSamplingComponent } from './route-call-sampling.component';

describe('RouteCallSamplingComponent', () => {
  let component: RouteCallSamplingComponent;
  let fixture: ComponentFixture<RouteCallSamplingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RouteCallSamplingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RouteCallSamplingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
