import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class RouteCallSamplingService {
  constructor(private http: HttpClient) { }
  
  loadData() {

    return this.http.get('./../assets/data/json/route-call.json');
  }
}
