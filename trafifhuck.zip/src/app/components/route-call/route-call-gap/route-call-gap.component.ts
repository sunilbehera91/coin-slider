import { Component, OnInit } from '@angular/core';
// import { RouteCallGapService } from './route-call-gap.service';
import { RouteCallService } from '../../../services/route-call.service';

@Component({
  selector: 'app-route-call-gap',
  templateUrl: './route-call-gap.component.html',
  styleUrls: ['./route-call-gap.component.scss'],
  providers: [RouteCallService]
})
export class RouteCallGapComponent implements OnInit {

  columnTabA: any = [];
  columnTabB: any = [];
  rowData: any = [];
  constructor(private _RouteCallService: RouteCallService) { }

  ngOnInit() {

    this._RouteCallService.loadData().subscribe(res => {


      let headers = res[0];
      const h = [];
      Object.keys(headers).map(item => {
        h.push(
          { headerName: item, field: item, sortable: true, filter: true }
        );
      });

      this.columnTabA = h.slice(0, 3);
      this.columnTabB = h.slice(3, h.length);

      setTimeout(() => {
        this.rowData = res;
      }, 0);

    }, err => {
      console.error(err);
    })
    
  }

}