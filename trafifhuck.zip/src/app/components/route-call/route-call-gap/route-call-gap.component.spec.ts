import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouteCallGapComponent } from './route-call-gap.component';

describe('RouteCallGapComponent', () => {
  let component: RouteCallGapComponent;
  let fixture: ComponentFixture<RouteCallGapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RouteCallGapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RouteCallGapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
