import { TestBed } from '@angular/core/testing';

import { RouteCallGapService } from './route-call-gap.service';

describe('RouteCallGapService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RouteCallGapService = TestBed.get(RouteCallGapService);
    expect(service).toBeTruthy();
  });
});
