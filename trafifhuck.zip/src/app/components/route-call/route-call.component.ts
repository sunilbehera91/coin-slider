import { Component, OnInit } from '@angular/core';
import { RouteCallService } from './route-call.service';
import { SelectedRoutersService } from '../selected-routers/selected-routers.service';

@Component({
  selector: 'app-route-call',
  templateUrl: './route-call.component.html',
  styleUrls: ['./route-call.component.scss'],
  providers: [RouteCallService ,SelectedRoutersService]
})
export class RouteCallComponent implements OnInit {
  color = 'accent';
  checked = false;
  disabled = false;

  private gridApi;
  private gridColumnApi;
  private columnDefs;
  private defaultColDef;

  columnTabA: any = [];
  columnTabB: any = [];

  rowData: any = [];


  constructor(private _RouteCallService: RouteCallService) { 

    this.columnDefs = [];
    this.defaultColDef = { width: 110 ,
      sortable: true,
      enableBrowserTooltips: true,
    };

  
  }

  ngOnInit() {

    this._RouteCallService.loadData().subscribe(res => {


      let headers = res[0];
      const h = [];
      Object.keys(headers).map(item => {
        h.push(
          { headerName: item, field: item, sortable: true, filter: true }
        );
      });

      this.columnTabA = h.slice(0, 3);
      this.columnTabB = h.slice(3, h.length);

      setTimeout(() => {
        this.rowData = res;
      }, 0);

    }, err => {
      console.error(err);
    })
    
  }


  onBtPrint() {
    var gridApi = this.gridApi;
    setPrinterFriendly(gridApi);
    setTimeout(function() {
      print();
      setNormal(gridApi);
    }, 2000);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    params.api.expandAll();
  }

}
var models = [
  "Mercedes-AMG C63",
  "BMW M2",
  "Audi TT Roadster",
  "Mazda MX-5",
  "BMW M3",
  "Porsche 718 Boxster",
  "Porsche 718 Cayman"
];
var colors = ["Red", "Black", "Green", "White", "Blue"];
var countries = ["UK", "Spain", "France", "Ireland", "USA"];
function createRowData() {
  var rowData = [];
  for (var i = 0; i < 200; i++) {
    var item = {
      id: i + 1,
      group: "Group " + (Math.floor(i / 20) + 1),
      model: models[Math.floor(Math.random() * models.length)],
      color: colors[Math.floor(Math.random() * colors.length)],
      country: countries[Math.floor(Math.random() * countries.length)],
      year: 2018 - Math.floor(Math.random() * 20),
      price: 20000 + Math.floor(Math.random() * 100) * 100
    };
    rowData.push(item);
  }
  return rowData;
}
function setPrinterFriendly(api) {
  var eGridDiv = document.querySelector(".my-grid");

  api.setDomLayout("print");
}
function setNormal(api) {
  var eGridDiv = document.querySelector(".my-grid");

  api.setDomLayout(null);
}