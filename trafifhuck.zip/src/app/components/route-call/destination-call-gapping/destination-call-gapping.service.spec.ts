import { TestBed } from '@angular/core/testing';

import { DestinationCallGappingService } from './destination-call-gapping.service';

describe('DestinationCallGappingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DestinationCallGappingService = TestBed.get(DestinationCallGappingService);
    expect(service).toBeTruthy();
  });
});
