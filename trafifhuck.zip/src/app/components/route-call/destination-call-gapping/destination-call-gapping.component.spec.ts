import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DestinationCallGappingComponent } from './destination-call-gapping.component';

describe('DestinationCallGappingComponent', () => {
  let component: DestinationCallGappingComponent;
  let fixture: ComponentFixture<DestinationCallGappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestinationCallGappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestinationCallGappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
