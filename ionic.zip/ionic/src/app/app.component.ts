import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }


  type = 'PieChart';
  data = [
      ['upto 3 days', 875],
      ['4 to 7 days', 1049],
      ['8 to 14 days', 1248],
      ['over 2 weeks', 818],

  ];
  columnNames = ['Browser', 'number'];
  options = {
      is3D: true,
      tooltip: { textStyle: { color: '#FF0000' }, showColorCode: true },

      pieSliceTextStyle: { color: 'black', fontSize: 12 },
      legend: { position: 'bottom' },

      backgroundColor: '#333333',

      pieSliceText: 'value',
      colors: ['#319BFC', '#A462F9', '#FFC84A', '#10E3BD'],
      chartArea: { x: 0, y: 0, left: 0, top: 0, right: 0, bottom: 0, width: "200", height: "100", }

  };
  width = 400;
  height = 150;
  
}
